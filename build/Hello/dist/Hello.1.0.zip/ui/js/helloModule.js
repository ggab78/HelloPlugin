/**
 * Create the module.
 */
var helloModule = angular.module('hello', ['ui.bootstrap']);